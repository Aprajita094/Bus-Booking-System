-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2022 at 07:04 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bms`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `buspro` ()  BEGIN
SELECT busname,source,dest,dept,arrival FROM buses;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `bbusno` int(11) NOT NULL,
  `bbusname` varchar(50) NOT NULL,
  `bbuscomp` varchar(50) NOT NULL,
  `bbustype` varchar(50) NOT NULL,
  `bsource` varchar(50) NOT NULL,
  `bdest` varchar(50) NOT NULL,
  `bdept` time NOT NULL,
  `barrival` time NOT NULL,
  `bprice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`bbusno`, `bbusname`, `bbuscomp`, `bbustype`, `bsource`, `bdest`, `bdept`, `barrival`, `bprice`) VALUES
(4, 'Reshma', 'Bharat', 'AC', 'Bengaluru', 'Mumbai', '19:00:00', '13:15:00', 1300);

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

CREATE TABLE `buses` (
  `busno` int(11) NOT NULL,
  `busname` varchar(50) NOT NULL,
  `buscomp` varchar(50) NOT NULL,
  `bustype` varchar(50) NOT NULL,
  `source` varchar(50) NOT NULL,
  `dest` varchar(50) NOT NULL,
  `dept` time NOT NULL,
  `arrival` time NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`busno`, `busname`, `buscomp`, `bustype`, `source`, `dest`, `dept`, `arrival`, `price`) VALUES
(1, 'VRL Travels', 'Volvo', 'Sleeper', 'Bengaluru', 'Mumbai', '16:00:00', '08:30:00', 1600),
(2, 'Orange Tours and Travels', 'Volvo', 'AC', 'Bengaluru', 'Mumbai', '16:00:00', '09:00:00', 1800),
(3, 'VRL Travels', 'Tata Motors', 'Sleeper', 'Bengaluru', 'Mumbai', '12:30:00', '05:30:00', 900),
(4, 'Reshma Tourist', 'Bharat Benz', 'AC', 'Bengaluru', 'Mumbai', '19:00:00', '13:15:00', 1300),
(5, 'National Travels', 'Bharat Benz', 'AC', 'Bengaluru', 'Mumbai', '14:10:00', '11:00:00', 1162),
(6, 'Reshma Tourist', 'Bharat Benz', 'AC-Sleeper', 'Mumbai', 'Bengaluru', '15:00:00', '10:30:00', 1100),
(7, 'National Travels', 'Bharat Benz', 'AC-Sleeper', 'Mumbai', 'Bengaluru', '14:45:00', '09:04:00', 1200),
(8, 'VRL Travels', 'Volvo', 'AC', 'Mumbai', 'Bengaluru', '12:30:00', '07:30:00', 1600),
(9, 'M R Travels', 'Tata Motors', 'AC', 'Mumbai', 'Bengaluru', '15:35:00', '10:35:00', 1410),
(10, 'Jakhar Travels', 'Volvo', 'Sleeper', 'Mumbai', 'Bengaluru', '16:30:00', '10:30:00', 3010),
(11, 'Jabbar Travels', 'Bharat Benz', 'AC-Sleeper', 'Bengaluru', 'Hyderabad', '22:00:00', '06:30:00', 1400),
(12, 'Intercity Travels', 'Bharat Benz', 'AC-Sleeper', 'Bengaluru', 'Hyderabad', '22:15:00', '06:30:00', 1400),
(13, 'KSM Road Lines', 'Tata Motors', 'AC', 'Bengaluru', 'Hyderabad', '22:00:00', '06:35:00', 1599),
(14, 'Rajan Transports', 'Volvo', 'AC', 'Bengaluru', 'Hyderabad', '21:45:00', '05:35:00', 1600),
(15, 'Hail Trip', 'Volvo', 'Sleeper', 'Bengaluru', 'Hyderabad', '21:50:00', '08:00:00', 750),
(16, 'Rajan Transports', 'Volvo', 'Sleeper', 'Hyderabad', 'Bengaluru', '16:00:00', '08:30:00', 1600),
(17, 'KSM Road Lines', 'Volvo', 'Sleeper', 'Hyderabad', 'Bengaluru', '16:00:00', '08:30:00', 1699),
(18, 'Orange Tours and Travels', 'Volvo', 'Sleeper', 'Hyderabad', 'Bengaluru', '16:00:00', '08:30:00', 900),
(19, 'Intercity Travels', 'Bharat Benz', 'AC', 'Hyderabad', 'Bengaluru', '16:00:00', '08:30:00', 1400),
(20, 'Jabbar Travels', 'Bharat Benz', 'AC', 'Hyderabad', 'Bengaluru', '16:00:00', '08:30:00', 1330),
(21, 'Venkatesh Tours and Travels', 'Bharat Benz', 'AC-Sleeper', 'Mumbai', 'Hyderabad', '17:00:00', '07:30:00', 1250),
(22, 'Jabbar Travels', 'Tata Motors', 'AC', 'Mumbai', 'Hyderabad', '16:35:00', '07:05:00', 1300),
(23, 'City Tours and Travels', 'Bharat Benz', 'AC', 'Mumbai', 'Hyderabad', '16:00:00', '08:50:00', 900),
(24, 'Orange Tours and Travels', 'Volvo', 'Sleeper', 'Mumbai', 'Hyderabad', '18:00:00', '07:30:00', 1500),
(25, 'SUR Tours and Travels', 'Tata Motors', 'AC', 'Mumbai', 'Hyderabad', '15:30:00', '06:30:00', 1790),
(26, 'Jabbar Travels', 'Volvo', 'AC', 'Hyderabad', 'Mumbai', '21:15:00', '10:45:00', 950),
(27, 'Orange Tours and Travels', 'Tata Motors', 'AC-Sleeper', 'Hyderabad', 'Mumbai', '16:45:00', '08:00:00', 1500),
(28, 'City Tours and Travels', 'Bharat Benz', 'AC', 'Hyderabad', 'Mumbai', '15:00:00', '06:00:00', 900),
(29, 'SUR Tours and Travels', 'Tata Motors', 'Sleeper', 'Hyderabad', 'Mumbai', '21:00:00', '10:30:00', 1300),
(30, 'Venkatesh Tours and Travels', 'Tata Motors', 'AC', 'Hyderabad', 'Mumbai', '19:15:00', '10:30:00', 1100),
(31, 'Maa Shanti Travels', 'Tata Motors', 'AC-Seater/Sleeper', 'Ranchi', 'Patna', '21:15:00', '06:00:00', 570),
(32, 'Suba Travels', 'Tata Motors', 'AC-Seater/Sleeper', 'Ranchi', 'Patna', '20:30:00', '05:30:00', 570),
(33, 'Prithvi Vahan', 'Volvo', 'AC-Sleeper', 'Ranchi', 'Patna', '21:00:00', '05:00:00', 799),
(34, 'Royal Arzoo', 'Bharat Benz', 'AC-Sleeper', 'Ranchi', 'Patna', '21:00:00', '05:30:00', 710),
(35, 'Bharat Paryatan', 'Volvo', 'AC-Seater/Sleeper', 'Ranchi', 'Patna', '20:30:00', '05:30:00', 570),
(36, 'Maa Shanti Travels', 'Tata Motors', 'AC-Seater/Sleeper', 'Patna', 'Ranchi', '21:15:00', '06:25:00', 650),
(37, 'Bharat Paryatan', 'Volvo', 'AC-Sleeper', 'Patna', 'Ranchi', '21:00:00', '06:00:00', 619),
(38, 'Royal Arzoo', 'Bharat Benz', 'AC', 'Patna', 'Ranchi', '21:00:00', '05:00:00', 710),
(39, 'Krishna Rath Luxury', 'Volvo', 'AC-Sleeper', 'Patna', 'Ranchi', '21:00:00', '05:00:00', 400),
(40, 'Vijay Rathn', 'Tata Motors', 'AC-Sleeper', 'Patna', 'Ranchi', '19:15:00', '04:45:00', 700),
(41, 'Shivam Travels', 'Volvo', 'AC', 'Kolkata', 'Ranchi', '21:00:00', '06:00:00', 570),
(42, 'Sri Sai Travels', 'Tata Motors', 'AC', 'Kolkata', 'Ranchi', '21:00:00', '05:30:00', 462),
(43, 'Royal Cruiser-Travel WorldClass', 'Volvo', 'AC', 'Kolkata', 'Ranchi', '20:00:00', '05:20:00', 952),
(44, 'Royal Travels', 'Bharat Benz', 'AC', 'Kolkata', 'Ranchi', '20:30:00', '05:00:00', 510),
(45, 'Baba Travels', 'Bharat Benz', 'Non-AC', 'Kolkata', 'Ranchi', '20:30:00', '06:00:00', 550),
(46, 'Shivam Travels', 'Volvo', 'AC', 'Ranchi', 'Kolkata', '20:30:00', '06:30:00', 475),
(47, 'Royal Cruiser', 'Volvo', 'AC', 'Ranchi', 'Kolkata', '20:30:00', '06:30:00', 475),
(48, 'Sai Rath', 'Tata Motors', 'AC-Sleeper', 'Ranchi', 'Kolkata', '21:00:00', '06:00:00', 462),
(49, 'Royal Travels', 'Bharat Benz', 'AC', 'Ranchi', 'Kolkata', '21:00:00', '05:30:00', 560),
(50, 'Baba Travels', 'Bharat Benz', 'Non-AC', 'Ranchi', 'Kolkata', '20:30:00', '06:00:00', 550),
(51, 'Bengal Tiger', 'Volvo', 'AC', 'Patna', 'Kolkata', '17:15:00', '09:00:00', 700),
(52, 'Bengal Tiger', 'Volvo', 'Non-AC', 'Patna', 'Kolkata', '16:30:00', '09:30:00', 555),
(53, 'Dayan & Company', 'Tata Motors', 'Non-AC', 'Patna', 'Kolkata', '17:30:00', '09:00:00', 555),
(54, 'JGD Travels', 'Bharat Benz', 'AC-Sleeper', 'Patna', 'Kolkata', '17:45:00', '06:00:00', 1030),
(55, 'Aitiana Airways', 'Tata Motors', 'AC-Sleeper', 'Patna', 'Kolkata', '19:00:00', '08:30:00', 800),
(56, 'Bengal Tiger', 'Volvo', 'AC', 'Kolkata', 'Patna', '19:45:00', '09:30:00', 700),
(57, 'Bengal Tiger', 'Volvo', 'Non-AC', 'Kolkata', 'Patna', '16:40:00', '09:00:00', 555),
(58, 'Dayan & Company', 'Tata Motors', 'Non-AC', 'Kolkata', 'Patna', '19:30:00', '09:30:00', 555),
(59, 'JGD Travels', 'Bharat Benz', 'AC-Sleeper', 'Kolkata', 'Patna', '17:00:00', '09:15:00', 1330),
(60, 'Aitiana Airways', 'Tata Motors', 'AC-Sleeper', 'Kolkata', 'Patna', '20:00:00', '10:30:00', 800);

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `pid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `pemail` varchar(50) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `doj` date NOT NULL,
  `pnumber` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`pid`, `id`, `pemail`, `pname`, `age`, `gender`, `doj`, `pnumber`) VALUES
(96, 23, 'getsetgo@gmail.com', 'Aditya Sinha', 20, 'Male', '2022-01-30', '9135615037');

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `tid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `number` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`tid`, `id`, `email`, `name`, `age`, `gender`, `date`, `number`) VALUES
(96, 23, 'getsetgo@gmail.com', 'Aditya Kumar', 20, 'Male', '2022-01-30', '9135615037');

--
-- Triggers `ticket`
--
DELIMITER $$
CREATE TRIGGER `BookingDeleted` BEFORE DELETE ON `ticket` FOR EACH ROW INSERT INTO trigr VALUES (NULL,OLD.tid,OLD.email,OLD.name,'BOOKING DELETED',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `BookingInsertion` AFTER INSERT ON `ticket` FOR EACH ROW INSERT INTO trigr VALUES (NULL,NEW.tid,NEW.email,NEW.name,'BOOKING INSERTED',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `BookingUpdated` AFTER UPDATE ON `ticket` FOR EACH ROW INSERT INTO trigr VALUES (NULL,NEW.tid,NEW.email,NEW.name,'BOOKING UPDATED',NOW())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `trigr`
--

CREATE TABLE `trigr` (
  `trid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `timestamp` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trigr`
--

INSERT INTO `trigr` (`trid`, `tid`, `email`, `name`, `action`, `timestamp`) VALUES
(157, 93, 'aditya@gmail.com', 'Aditya', 'BOOKING DELETED', '2022-01-29 23:27:10'),
(158, 94, 'aditya@gmail.com', 'Anita', 'BOOKING DELETED', '2022-01-29 23:27:10'),
(159, 95, 'aditya@gmail.com', 'Aprajita', 'BOOKING DELETED', '2022-01-29 23:27:10'),
(160, 96, 'getsetgo@gmail.com', 'Aditya Sinha', 'BOOKING INSERTED', '2022-01-29 23:31:03'),
(161, 96, 'getsetgo@gmail.com', 'Aditya Kumar', 'BOOKING UPDATED', '2022-01-29 23:31:19');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`) VALUES
(11, 'GetSetGo', 'getsetgo@gmail.com', 'pbkdf2:sha256:260000$H3Hstv01EolaWatm$530fb749d48e6006047ad20c508d2bfa51d9a74795e4504cfbcba047a9bd3239');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buses`
--
ALTER TABLE `buses`
  ADD PRIMARY KEY (`busno`);

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `trigr`
--
ALTER TABLE `trigr`
  ADD PRIMARY KEY (`trid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buses`
--
ALTER TABLE `buses`
  MODIFY `busno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `passenger`
--
ALTER TABLE `passenger`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `trigr`
--
ALTER TABLE `trigr`
  MODIFY `trid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `passenger`
--
ALTER TABLE `passenger`
  ADD CONSTRAINT `passenger_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `ticket` (`tid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
