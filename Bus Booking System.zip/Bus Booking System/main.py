#Flask module for using flask
#Sqlalchemy library for connecting frontend and backend(mysql) using python
#importing flask
from flask import Flask,render_template,request,session,redirect,url_for,flash

#importing sqlalchemy
from flask_sqlalchemy import SQLAlchemy


#importing flask login for encrypted & decrypted password stored in db
from flask_login import UserMixin

#for hashed function which helps in encryption & decryption
from werkzeug.security import generate_password_hash,check_password_hash

from flask_login import login_user,logout_user,login_manager,LoginManager
from flask_login import login_required,current_user

#to send email
from flask_mail import Mail

#For importing json file
import json

# import MySQLdb
# dc=MySQLdb.connect("localhost","root","","bms")


# #For stored procedure
# import mysql.connector
# from mysql.connector import Error

# try:
#     connection = mysql.connector.connect(host='localhost',database='bms',user='astrio',password='10122020')
#     cursor = connection.cursor()
#     cursor.callproc('pro', [1, ])
#     # print results
#     print("Printing laptop details")
#     for result in cursor.stored_results():
#         print(result.fetchall())

# except mysql.connector.Error as error:
#     print("Failed to execute stored procedure: {}".format(error))
# finally:
#     if (connection.is_connected()):
#         cursor.close()
#         connection.close()
#         print("MySQL connection is closed")




# with open('config.json','r') as c:
#     params = json.load(c)["params"]



#My database connection
local_server = True
app = Flask(__name__)
app.secret_key = 'adityasinha'          #secret_key


#This is for unique user access
login_manager=LoginManager(app)
login_manager.login_view='login'


# SMTP Mail Server Setting

# app.config.update(
#     MAIL_SERVER='smtp.gmail.com',
#     MAIL_PORT='465',
#     MAIL_USE_SSL=True,
#     MAIL_USERNAME=params['gmail-user'],
#     MAIL_PASSWORD=params['gmail-password']
# )
# mail = Mail(app)




@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


#app.config['SQLALCHEMY_DATABASE_URL'] = 'mysql://username:password@localhost/database_table_name'               #for loading bms(bus management system) in main.py file
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/bms'                                            #for xampp by default we have username as root and password as nothing and database name is bms for me  
db=SQLAlchemy(app)          #passing app config to database



#we will create class for each tables in our database
#to access db from server we are initialising db_name i.e test
#we will create db models that is tables
#because we have given table_name as test & class_name starts with capital
class Test(db.Model):
    id = db.Column(db.Integer,primary_key=True)
    name = db.Column(db.String(100))                  #attributes are name & email
    email = db.Column(db.String(100))


class User(UserMixin,db.Model):
    id = db.Column(db.Integer,primary_key=True)
    username = db.Column(db.String(50))
    email = db.Column(db.String(50),unique=True)
    password = db.Column(db.String(1000))


class Ticket(db.Model):
    tid=db.Column(db.Integer,primary_key=True)
    id=db.Column(db.Integer)
    email=db.Column(db.String(50))
    name=db.Column(db.String(50))
    age=db.Column(db.Integer)
    gender=db.Column(db.String(50))
    date=db.Column(db.String(50),nullable=False)
    number=db.Column(db.String(50))



class Buses(db.Model):
    busno=db.Column(db.Integer,primary_key=True)
    busname=db.Column(db.String(50))
    buscomp=db.Column(db.String(50))
    bustype=db.Column(db.String(50))
    source=db.Column(db.String(50))
    dest=db.Column(db.String(50))
    dept=db.Column(db.String(50),nullable=False)
    arrival=db.Column(db.String(50),nullable=False)
    price=db.Column(db.Integer)


class Book(db.Model):
    bbusno=db.Column(db.Integer,primary_key=True)
    bbusname=db.Column(db.String(50))
    bbuscomp=db.Column(db.String(50))
    bbustype=db.Column(db.String(50))
    bsource=db.Column(db.String(50))
    bdest=db.Column(db.String(50))
    bdept=db.Column(db.String(50),nullable=False)
    barrival=db.Column(db.String(50),nullable=False)
    bprice=db.Column(db.Integer)


# class Passenger(db.Model):
#     pid=db.Column(db.Integer,primary_key=True)
#     pemail=db.Column(db.String(50))
#     pname=db.Column(db.String(50))
#     age=db.Column(db.Integer)
#     gender=db.Column(db.String(50))
#     doj=db.Column(db.String(50),nullable=False)
#     pnumber=db.Column(db.String(50))




class Trigr(db.Model):
    trid=db.Column(db.Integer,primary_key=True)
    tid=db.Column(db.Integer)
    email=db.Column(db.String(50))
    name=db.Column(db.String(50))
    action=db.Column(db.String(50))
    timestamp=db.Column(db.String(50))
    



# Here we will pass endpoints and run the functions
@app.route('/')                     #for routing.....get an IP address
def index():
    # a=Test.query.all()
    # print(a)
    #return render_template('index.html') 
    # try:
    #     Test.query.all()
    #     return 'My Database is connected'
    # except:
    #     return 'My Database is not connected'
    return render_template('index.html')


@app.route('/bus')
def bus():
    return render_template('bus.html')




#For Bus Booking Detail Page i.e for buses.html page

# @app.route('/buses',methods=['POST','GET'])
# def buses():
#     if request.method=="POST":
#         busno=request.form.get('busno')
#         busname=request.form.get('busname')
#         buscomp=request.form.get('buscomp')
#         bustype=request.form.get('bustype')
#         source=request.form.get('source')
#         dest=request.form.get('dest')
#         dept=request.form.get('dept')
#         arrival=request.form.get('arrival')
#         price=request.form.get('price')
#         query=db.engine.execute(f"INSERT INTO `buses` (`busno`,`busname`,`buscomp`,`bustype`,`source`,`dest`,`dept`,`arrival`,`price`) VALUES ('{busno}','{busname}','{buscomp}','{bustype}','{source}','{dest}','{dept}','{arrival}','{price}')")
#         flash("Booking Confirmed","primary")
#         return redirect('/bookings')


#     return render_template('buses.html')





# @app.route('/route')
# @login_required
# def route():
#     return render_template('route.html')



#For inserting values taken from ticket page  i.e ticket.html

@app.route('/ticket',methods=['POST','GET'])
@login_required
def ticket():
    #bus=db.engine.execute("SELECT * FROM `buses`")
    

    if request.method=="POST":
        id=request.form.get('id')
        email=request.form.get('email')
        name=request.form.get('name')
        age=request.form.get('age')
        gender=request.form.get('gender')
        date=request.form.get('date')
        number=request.form.get('number')
        source=request.form.get('source')
        dest=request.form.get('dest')

        query=db.engine.execute(f"INSERT INTO `ticket` (`id`,`email`,`name`,`age`,`gender`,`date`,`number`) VALUES ('{id}','{email}','{name}','{age}','{gender}','{date}','{number}')")
        
        
        query=db.engine.execute(f"INSERT INTO `passenger` (`id`,`pemail`,`pname`,`age`,`gender`,`doj`,`pnumber`) SELECT DISTINCT(`id`),`email`,`name`,`age`,`gender`,`date`,`number` FROM `ticket` WHERE `ticket`.`id`='{id}'")
        #query=db.engine.execute(f"INSERT INTO `passenger` (`pemail`,`pname`,`age`,`gender`,`doj`,`pnumber`,`source`,`dest`) VALUES ('{email}','{name}','{age}','{gender}','{date}','{number}','{source}','{dest}')")
        #s=db.engine.execute(f"INSERT INTO `schedule` (`email`,`source`,`dest`) VALUES ('{email}','{source}','{dest}')")
        #mail.send_message('GETSETGO BOOKING SYSTEM',sender=params['gmail-user'], recipients= ['adityasinha205@gmail.com'] , body=f"YOUR BOOKING IS CONFIRMED THANK YOU FOR CHOOSING US.\nYour Entered Details are :\nEmail-id: {email}\n Name: {name}\n Date: {date} \n Contact Details: {number}'")
       
        #flash("Booking Confirmed","info")
        return redirect('/bookings')
        
     
    return render_template('ticket.html',bus=bus)





#For bookings
@app.route('/bookings')
@login_required
def bookings():
    #only for current user, details will be displayed in booking details by this query.
    em=current_user.email
    query=db.engine.execute(f"SELECT * FROM `ticket` WHERE `ticket`.`email`='{em}'")


   # mail.send_message('GETSETGO BOOKING SYSTEM',sender='sinhaaditya43@gmail.com',recipients=[params['gmail-user']],body='Your booking is confirmed. Thanks for choosing us.')


    return render_template('booking.html',username=current_user.username,query=query)              #,username=current_user.username        For displaying current_user name in booking page




#For booking from busdetails i.e busdetails.html
@app.route('/busdetails')
@login_required
def busdetails():
    query=db.engine.execute(f"SELECT * FROM `buses`")
    return render_template('busdetails.html',query=query)                #originally  return render_template('busdetails.html',query=query) 


#For passenger details i.e pas.html
@app.route('/pas')
@login_required
def pas():
    query=db.engine.execute(f"SELECT DISTINCT(id),`pemail`,`pname`,`age`,`gender`,`doj`,`pnumber` FROM `passenger`")
    return render_template('pas.html',query=query)


#For booked bus details
@app.route("/finalbooking/<string:busno>",methods=['POST','GET'])
@login_required
def book(busno):
    posts=Buses.query.filter_by(busno=busno).first()                            #  Ticket.query.filter_by(tid=tid).first()
    if request.method=="POST":
        bbusno=request.form.get('busno')
        bbusname=request.form.get('busname')
        bbuscomp=request.form.get('buscomp')
        bbustype=request.form.get('bustype')
        bsource=request.form.get('source')
        bdest=request.form.get('dest')
        bdept=request.form.get('dept')
        barrival=request.form.get('arrival')
        bprice=request.form.get('price')
        query=db.engine.execute(f"INSERT INTO `book`(`bbusno`, `bbusname`, `bbuscomp`, `bbustype`, `bsource`, `bdest`, `bdept`, `barrival`, `bprice`) VALUES ('{bbusno}','{bbusname}','{bbuscomp}','{bbustype}','{bsource}','{bdest}','{bdept}','{barrival}','{bprice}')")
        
        return redirect('/final')

    return render_template('finalbooking.html',posts=posts)





#For booking from busdetails i.e busdetails.html
@app.route('/final')
@login_required
def final():
    query=db.engine.execute(f"SELECT * FROM book")
    flash("Booking Confirmed","success")
    return render_template('finaldetail.html',query=query) 



@app.route('/busbook')
@login_required
def busbook():
    query=db.engine.execute(f"SELECT * FROM book")
    return render_template('finaldetail.html',query=query) 



#To update the details of booking i.e edit.html

@app.route("/edit/<string:tid>",methods=['POST','GET'])                     # Originally  /edit/<string:tid>
@login_required
def edit(tid):                                                              # Originally edit(tid)
    posts=Ticket.query.filter_by(tid=tid).first()                            #  Ticket.query.filter_by(tid=tid).first()
    #pos=Schedule.query.filter_by(email=email).first()
    if request.method=="POST":
        email=request.form.get('email')
        name=request.form.get('name')
        age=request.form.get('age')
        gender=request.form.get('gender')
        date=request.form.get('date')
        number=request.form.get('number')
        source=request.form.get('source')
        dest=request.form.get('dest')
        db.engine.execute(f"UPDATE `ticket` SET `email`='{email}', `name`='{name}', `age`='{age}',`gender`='{gender}', `date`= '{date}', `number`= '{number}' WHERE `ticket`.`tid`= {tid}")
        #db.engine.execute(f"UPDATE `schedule` SET `source`='{source}', `dest`='{dest}'")
        flash("Booking is Updated","success")
        return redirect('/bookings')

    return render_template('edit.html',posts=posts)




#For deleting the booking details 
@app.route("/delete/<string:tid>",methods=['POST','GET'])
@login_required
def delete(tid):
    db.engine.execute(f"DELETE FROM `ticket` WHERE `ticket`.`tid`={tid}")
    #db.engine.execute(f"DELETE FROM `schedule` WHERE `ticket`.`tid`={tid}")
    flash("Deleted Successful","danger")
    return redirect('/bookings')





#For signup i.e signup.html
@app.route('/signup',methods=['POST','GET'])
def signup():
    if request.method == "POST":
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        #print(username,email,password)
        user=User.query.filter_by(email=email).first()
        if user:
            flash("Email Already Exist","warning")
            return render_template('/signup.html')
        encpassword=generate_password_hash(password)

        #used to insert values in db after signup
        new_user=db.engine.execute(f"INSERT INTO `user` (`username`,`email`,`password`) VALUES ('{username}','{email}','{encpassword}')")
              
                #or

        #This is 2 method used to insert values in db after signup both above and this below will do same thing
       
        # newuser=User(user=username,email=email,password=encpassword)
        # db.session.add(newuser)
        # db.session.commit()

        flash("Signup Successfully. Please Login","success")
        return render_template('login.html')    

    return render_template('signup.html')



#For login i.e login.html page

@app.route('/login',methods=['POST','GET'])
def login():
    if request.method == "POST":

        email = request.form.get('email')
        password = request.form.get('password')
        #print(email,password)
        user=User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password,password):
            login_user(user)
            flash("Login Successful","primary")
            return redirect(url_for('index'))
        else:
            flash("Invalid Credentials","danger")
            return render_template('login.html')

    return render_template('login.html')



#For logout
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Logout Successful","warning")
    return redirect(url_for('login'))


#For deleting account
@app.route('/deleteacc')
@login_required
def deleteacc():
    cid=current_user.id
    db.engine.execute(f"DELETE FROM `user` WHERE `user`.`id`={cid}")
    flash("Your Account is Deleted Successfully","warning")
    return redirect(url_for('login'))



#For searching
@app.route('/search',methods=['POST','GET'])
@login_required
def search():
    if request.method=="POST":
        query=request.form.get('search')
        buscomp=Buses.query.filter_by(buscomp=query).first()        #search for first appearance of buscomp name in buses table
        #busname=Buses.query.filter_by(busname=query).first()
        if buscomp:
            flash("Bus is Available","info")
        else:
            flash("Bus is not Available","danger")
   

    return render_template('index.html')





#For triggers
@app.route('/history')
@login_required
def history():
    em=current_user.email
    query=db.engine.execute(f"SELECT * FROM `trigr` WHERE email='{em}'")
    #posts=Trigr.query.all()                                                            #If I use this line of code then pasdetails will show to everyone
    return render_template('triggers.html',posts=query)


#For procedure
@app.route('/procedure')
@login_required
def procedure():
    posts=db.engine.execute("CALL buspro()")
    return render_template('procedure.html',posts=posts)







# @app.route('/pas')
# @login_required
# def pas():
#     em=current_user.email
#     query=db.engine.execute(f"SELECT * FROM `passenger` WHERE pemail='{em}'")

#     return render_template('pas.html',query=query)








#For understanding purpose below code
# @app.route('/test')
# def test():
#     try:
#         Test.query.all()
#         return 'My Database is connected'
#     except:
#         return 'My Database is not connected'

#     #return render_template('test.html')             #this will link test.html file with this main file and return the text.html content


#For home page i.e / or /home same thing
@app.route("/home")
def home():
    return "<p>Hello Aditya , this is my home page</p>"


app.run(debug=True)     #For running this flask code